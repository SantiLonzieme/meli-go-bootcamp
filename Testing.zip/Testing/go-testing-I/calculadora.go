package calculadora

func Restar(num1, num2 int) int {
	return num1 - num2
}
